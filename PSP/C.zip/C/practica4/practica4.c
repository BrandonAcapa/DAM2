#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
int main()
{
    int fd[2];
    pid_t pid;
    char saludoPadre[] = "Hola Papi\0";
    char buffer[sizeof(saludoPadre) + 1];
    pipe(fd);
    pid = fork();
    switch (pid)
    {
    case 1:
        printf("No s'ha pogut crear el procés fill\n");
        exit(1);
    case 0:
        close(fd[0]);
        printf("El fill envia al pare...\n");
        write(fd[1], saludoPadre, strlen(saludoPadre) + 1);
        wait(NULL);
        break;
    default:
        close(fd[1]);
        read(fd[0], buffer, sizeof(saludoPadre) + 1);
        printf("El pare rep del fill: %s\n", buffer);

        break;
    }
    return 0;
}