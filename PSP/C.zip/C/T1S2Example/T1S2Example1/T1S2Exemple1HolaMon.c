 #include <stdio.h>
 int main( int argc, char *argv[] )
 {
 printf( "Hola, món!\n");
 return 0;
 }