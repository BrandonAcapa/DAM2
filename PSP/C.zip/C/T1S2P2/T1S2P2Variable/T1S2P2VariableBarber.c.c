#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    pid_t pid1;
    int val = 6;
    pid1 = fork();
    if (pid1 == 0)
    {
        printf("Soc el fill %d, y val = %d\n", getpid(), val - 5);
    }
    else
    {
        printf("Soc el pare %d, y val = %d\n", getpid(), val + 5);

    }

    return 0;
}