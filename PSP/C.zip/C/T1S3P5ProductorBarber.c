#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
int main()
{
    int fp;
    char buffer[256];;

    fp = open("FIFO1", 1);
    if (fp == -1) {
        printf("ERROR AL ABRIR ARCHIVO\n");
        exit(1);
    }

    printf("Escribe mensajes para enviar por FIFO (Ctrl+C para salir):\n");

    while (1) {
        // Leer del usuario
        printf("> ");
        fflush(stdout);
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            break; // si hay error o EOF
        }

        // Eliminar salto de línea al final
        buffer[strcspn(buffer, "\n")] = '\0';

        // Enviar al FIFO
        if (write(fp, buffer, strlen(buffer)) == -1) {
            perror("Error al escribir en FIFO");
            break;
        }
    }

    close(fp);
    return 0;
}