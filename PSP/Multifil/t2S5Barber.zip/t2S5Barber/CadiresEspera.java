package t2S5Barber;

import java.util.LinkedList;
import java.util.Queue;

public class CadiresEspera {
    private final int MAX_SILLAS;
    private final Queue<Integer> colaClientes; // Cola para mantener el orden de llegada

    public CadiresEspera(int numSillas) {
        this.MAX_SILLAS = numSillas;
        this.colaClientes = new LinkedList<>();
    }

    public synchronized boolean ocuparSilla(int id) {
        if (colaClientes.size() < MAX_SILLAS) {
            colaClientes.offer(id);
            System.out.println("-> Client" + id + " seu en una CADIRA d'espera. Ocupadas: " + colaClientes.size());
            return true;
        } else {
            System.out.println("-> Client" + id + " SE VA DE LA BARBERIA. (Sillas llenas)");
            return false;
        }
    }

    public synchronized int dejarSilla() {
        return colaClientes.poll();
    }

    public synchronized int getProximoClienteId() {
        return colaClientes.peek() != null ? colaClientes.peek() : -1;
    }

    public synchronized boolean hayClientesEsperando() {
        return !colaClientes.isEmpty();
    }
}