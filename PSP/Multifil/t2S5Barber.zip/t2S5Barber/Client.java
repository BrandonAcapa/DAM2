package t2S5Barber;

public class Client extends Thread {
    private final ButacaBarber butacaBarber;
    private final CadiresEspera cadiresEspera;
    private final int id;

    public Client(ButacaBarber butacaBarber, CadiresEspera cadiresEspera, int id) {
        this.butacaBarber = butacaBarber;
        this.cadiresEspera = cadiresEspera;
        this.id = id;
    }

    @Override
    public void run() {
        if (butacaBarber.sentarseButaca(id)) {
            return;
        }

        if (cadiresEspera.ocuparSilla(id)) {
            
            boolean sentadoEnButaca = false;
            while (!sentadoEnButaca) {
                if (cadiresEspera.getProximoClienteId() == id) {
                    
                    if (butacaBarber.sentarseButaca(id)) {
                        cadiresEspera.dejarSilla();
                        sentadoEnButaca = true;
                    } else {
                        try {
                            Thread.sleep(100); 
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                } else {
                    try {
                        Thread.sleep(100); 
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
    }
}