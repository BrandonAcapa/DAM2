package t2S5Barber;

public class ButacaBarber {
    private int clientButacaId = -1;
    private boolean barberoDurmiendo = true;

    public synchronized boolean sentarseButaca(int id) {
        if (clientButacaId == -1) {
            clientButacaId = id;
            System.out.println("-> Client" + id + " seu en la BUTACA");

            if (barberoDurmiendo) {

                System.out.println("-> Client" + id + " DESPIERTA al barbero.");
                barberoDurmiendo = false;
                notify();
            }
            return true;
        } else {
            System.out.println("-> Client" + id + " ha intentat seure en BUTACA pero no pot.");
            return false;
        }
    }

    public synchronized int cortarPelo() {
        while (clientButacaId == -1) {
            barberoDurmiendo = true;
            try {
                System.out.println("Barbero se acuesta a DORMIR.");
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        int idClienteAtendido = clientButacaId;
        System.out.println("Barbero empieza a cortar el pelo a Client" + idClienteAtendido);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        clientButacaId = -1;
        System.out.println("-> Barber ha TALLAT el cabell a " + idClienteAtendido + ".");
        barberoDurmiendo = false;
    
        return idClienteAtendido;
    }
}