package t2S5Barber;

public class Barber extends Thread {
    private final ButacaBarber butacaBarber;

    public Barber(ButacaBarber butacaBarber) {
        this.butacaBarber = butacaBarber;
    }

    @Override
    public void run() {
        while (true) {
            butacaBarber.cortarPelo();
        }
    }
}