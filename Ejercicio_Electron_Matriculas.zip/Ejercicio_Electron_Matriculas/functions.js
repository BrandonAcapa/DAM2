document.addEventListener('DOMContentLoaded', () => {
    
    const fs = require('fs');
    const fichero = fs.readFileSync('./asignaturas.json');
    const tabla = document.getElementById('tabla');
    const curso = document.getElementById('curso');
    const asignaturas = JSON.parse(fichero);
    let horasTotales = 0;

    function actualizarHorasTotales() {
        const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
        horasTotales = 0;
        checkboxes.forEach(checkbox => {
            horasTotales += parseInt(checkbox.dataset.horas);
        });
        document.getElementById('horasTotales').textContent = horasTotales;
    }

    function guardarMatricula() {
        const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
        const asignaturasSeleccionadas = Array.from(checkboxes).map(checkbox => ({
            nombre: checkbox.dataset.nombre,
            horas: parseInt(checkbox.dataset.horas),
            curso: checkbox.dataset.curso
        }));

        const matricula = {
            fecha: new Date().toISOString(),
            curso: document.getElementById('curso').value,
            asignaturas: asignaturasSeleccionadas,
            horasTotales: horasTotales
        };

        fs.writeFileSync('./matricula.json', JSON.stringify(matricula, null, 2));
        alert('Matrícula guardada correctamente');
    }

    function mostrarAsignaturas(e) {
        let asigCurso = asignaturas.filter(asig => asig.curso === e);
        tabla.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Horas</th>
                    <th>Cursar</th>
                </tr>
            </thead>
            <tbody>
                ${asigCurso.map(asig => `
                    <tr>
                        <td>${asig.nombre}</td>
                        <td>${asig.horas}</td>
                        <td>
                            <input type="checkbox" 
                                data-nombre="${asig.nombre}"
                                data-horas="${asig.horas}"
                                data-curso="${asig.curso}"
                                onchange="actualizarHorasTotales()">
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
        <div id="guardar">
            <p>Total de horas seleccionadas: <span id="horasTotales">0</span></p>
            <button onclick="guardarMatricula()" class="guardar-btn">Guardar Matrícula</button>
        </div>`;

        window.actualizarHorasTotales = actualizarHorasTotales;
        window.guardarMatricula = guardarMatricula;
    }

    curso.addEventListener('change', function(){
        if (this.value) {
            mostrarAsignaturas(this.value);
        } else {
            tabla.innerHTML = `<p>Por favor seleccione un curso</p>`;
        }
    });
});