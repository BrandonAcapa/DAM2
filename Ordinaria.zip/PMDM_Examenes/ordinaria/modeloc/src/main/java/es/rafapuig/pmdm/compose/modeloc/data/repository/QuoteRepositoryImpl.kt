package es.rafapuig.pmdm.compose.modeloc.data.repository

import es.rafapuig.pmdm.compose.modeloc.data.local.QuoteDao
import es.rafapuig.pmdm.compose.modeloc.data.local.toDomain
import es.rafapuig.pmdm.compose.modeloc.data.local.toEntity
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.domain.repository.QuoteRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class QuoteRepositoryImpl(private val quoteDao: QuoteDao) : QuoteRepository {

    override fun getQuotes(): Flow<List<Quote>> {
        return quoteDao.getAllQuotes().map { quotes ->
            quotes.map { it.toDomain() }
        }
    }

    override suspend fun toggleFavorite(id: Int) {
        quoteDao.toggleFavorite(id)
    }

    override fun searchQuotes(query: String): Flow<List<Quote>> {
        return quoteDao.searchQuotes(query).map { quotes ->
            quotes.map { it.toDomain() }
        }
    }

    override fun getQuoteById(id: Int): Flow<Quote> {
        return quoteDao.getQuoteById(id).map { it.toDomain() }
    }

    override fun getRandomQuote(): Flow<Quote> {
        return quoteDao.getRandomQuote().map { it.toDomain() }
    }

}