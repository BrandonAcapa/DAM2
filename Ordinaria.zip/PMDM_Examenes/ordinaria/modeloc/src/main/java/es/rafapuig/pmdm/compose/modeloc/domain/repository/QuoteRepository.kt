package es.rafapuig.pmdm.compose.modeloc.domain.repository

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import kotlinx.coroutines.flow.Flow

interface QuoteRepository {

    fun getQuotes(): Flow<List<Quote>>
    fun searchQuotes(query: String): Flow<List<Quote>>
    fun getQuoteById(id: Int): Flow<Quote>
    fun getRandomQuote(): Flow<Quote>
    suspend fun toggleFavorite(id: Int)
}