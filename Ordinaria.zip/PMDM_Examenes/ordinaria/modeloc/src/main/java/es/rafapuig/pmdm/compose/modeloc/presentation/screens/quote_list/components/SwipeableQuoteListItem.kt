package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.math.abs

@Composable
fun rememberVibrator(): Vibrator {
    val context = LocalContext.current

    return remember(context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager =
                context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }
}

fun Vibrator.vibrateTelegramStyle() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrate(
            VibrationEffect.createOneShot(
                30,   // duración muy corta
                120   // amplitud media-alta (1–255)
            )
        )
    } else {
        @Suppress("DEPRECATION")
        vibrate(30)
    }
}

@Composable
fun SwipeableQuoteListItem(
    quote: Quote,
    modifier: Modifier = Modifier,
    onQuoteClick: (Quote) -> Unit = {},
    onFavoriteClick: (Quote) -> Unit = {},
    onQuoteSwiped: (Quote) -> Unit = {}
) {
    val haptic = LocalHapticFeedback.current
    val vibrator = rememberVibrator()

    val swipeToDismissBoxState = rememberSwipeToDismissBoxState(
        positionalThreshold = { totalDistance ->
            totalDistance * 0.8f
        }
    )

    var widthPx by remember { mutableFloatStateOf(0f) }
    var hasVibrated by remember { mutableStateOf(false) }

    /*var alreadyDeleted by remember { mutableStateOf(false) }

    val swipeToDismissBoxState =
        rememberSwipeToDismissBoxState(
            SwipeToDismissBoxValue.Settled,
            confirmValueChange = {
                if (it == SwipeToDismissBoxValue.EndToStart /* && !alreadyDeleted*/) {
                    /*alreadyDeleted = true*/
                    Log.d("QuoteList", "Deleting quote swiped: $quote")
                    //onQuoteSwiped(quote)

                     //🔹 Vibración
                     haptic.performHapticFeedback(
                         HapticFeedbackType.LongPress
                    )

                   /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(
                            VibrationEffect.createOneShot(
                                100, // duración ms
                                VibrationEffect.DEFAULT_AMPLITUDE
                            )
                        )
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(100)
                    }*/
                }
                //true
                //false
                //it == SwipeToDismissBoxValue.EndToStart
                false
            }
        )

     */

    //var alreadyDeleted by remember { mutableStateOf(false) }

    val updatedQuote = rememberUpdatedState(quote)

    /**
     * 🔎 ¿Por qué targetValue y no currentValue?
     * currentValue cambia cuando la animación termina.
     * targetValue cambia cuando el gesto cruza el threshold.
     */
    LaunchedEffect(swipeToDismissBoxState) {
        snapshotFlow { swipeToDismissBoxState.targetValue } //currentValue
            .distinctUntilChanged()
            .collect { value ->
                if (value == SwipeToDismissBoxValue.EndToStart /*&& !alreadyDeleted*/) {
                    // dispara animación de salida / eliminación

                    //              alreadyDeleted = true
                    // 🔹 Vibración
//                    haptic.performHapticFeedback(
//                        HapticFeedbackType.TextHandleMove
//                    )

                    vibrator.vibrateTelegramStyle()

                    //visible = false
                    Log.d("QuoteList", "Deleting quote swiped effect: $quote")
                    onQuoteSwiped(updatedQuote.value)
                    swipeToDismissBoxState.snapTo(SwipeToDismissBoxValue.Settled)
                }
            }
    }

    /* var alreadyDeleted by remember { mutableStateOf(false) }

     LaunchedEffect(swipeToDismissBoxState.currentValue) {
         if (
             swipeToDismissBoxState.currentValue == SwipeToDismissBoxValue.EndToStart &&
             !alreadyDeleted
         ) {
             alreadyDeleted = true
             Log.d("QuoteList", "Deleting quote swiped effect: $quote")
             onQuoteSwiped(quote)
         }
     }*/



    SwipeToDismissBox(
        state = swipeToDismissBoxState,
        enableDismissFromStartToEnd = false,
        enableDismissFromEndToStart = true,
        modifier = Modifier
            .fillMaxWidth()
            .onSizeChanged {
                widthPx = it.width.toFloat()
            },
        /*onDismiss = {
            if (it == SwipeToDismissBoxValue.EndToStart) {
                onQuoteSwiped(quote)
            }
        },*/
        backgroundContent = {
            when (swipeToDismissBoxState.dismissDirection) {
                SwipeToDismissBoxValue.EndToStart -> {

                    val startColor = MaterialTheme.colorScheme.background

                    val background = lerp(
                        startColor,
                        Color.Red,
                        1 - swipeToDismissBoxState.progress / 4.0f
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(background)
                            .wrapContentSize(Alignment.CenterEnd)
                            .padding(12.dp)
                    ) {

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {

                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Eliminar cita",
                                modifier = Modifier.size(32.dp),
                                tint = Color.White
                            )
                            Text(
                                "Eliminar",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                SwipeToDismissBoxValue.StartToEnd -> {}
                SwipeToDismissBoxValue.Settled -> {}
            }

        }
    ) {

        // 👇 Observamos el offset de forma segura
        LaunchedEffect(swipeToDismissBoxState, widthPx) {
            if (widthPx == 0f) return@LaunchedEffect

            snapshotFlow { swipeToDismissBoxState.requireOffset() }
                .collect { offset ->

                    //Log.d("QuoteList", "Offset: $offset")

                    val percent =
                        (abs(offset) / widthPx).coerceIn(0f, 1f)

                    //Log.d("QuoteList", "Percent: $percent")

                    if (percent > 0.25f && !hasVibrated) {
                        hasVibrated = true
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }

                    if (percent < 0.25f) {
                        hasVibrated = false
                    }
                }
        }

        Box(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.background)
        ) {
            QuoteListItem(
                quote = quote,
                modifier = modifier,
                onQuoteClick = onQuoteClick,
                onFavoriteClick = onFavoriteClick
            )
            /*Button(onClick = {
                haptic.performHapticFeedback(
                        HapticFeedbackType.LongPress
                    )
                //vibrator.vibrateTelegramStyle()
            }) {
                Text("Eliminar")
            }*/
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SwipeableQuoteListItemPreview(
    @PreviewParameter(QuotePreviewProvider::class)
    quote: Quote
) {
    SwipeableQuoteListItem(quote = quote)
}