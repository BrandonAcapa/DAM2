package es.rafapuig.pmdm.compose.modeloc

import android.app.Application
import es.rafapuig.pmdm.compose.modeloc.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class QuoteApp : Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@QuoteApp)
            modules(appModule)
        }
    }
}