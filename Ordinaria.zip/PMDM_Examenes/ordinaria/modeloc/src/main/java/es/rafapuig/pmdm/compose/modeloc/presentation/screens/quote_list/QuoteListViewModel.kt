package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.GetFilteredQuotesUseCase
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.GetRandomQuoteUseCase
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.ToggleFavoriteUseCase
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.milliseconds

class QuoteListViewModel(
    private val getRandomQuoteUseCase: GetRandomQuoteUseCase,
    private val toggleFavoriteUseCase: ToggleFavoriteUseCase,
    private val getFilteredQuotesUseCase: GetFilteredQuotesUseCase,
) : ViewModel() {

    private val _uiState =
        MutableStateFlow(
            QuoteListUiState(
                query = "",
                quotes = emptyList(),
                showSearchBar = false,
                showFilterFavorites = false
            )
        )
    val uiState: StateFlow<QuoteListUiState> = _uiState.asStateFlow()


    private val _eventChannel = Channel<QuoteListEvent>()
    val events = _eventChannel.receiveAsFlow()

    private suspend fun notifyEvent(event: QuoteListEvent) {
        _eventChannel.send(event)
    }

    init {
        observeQuery()
    }

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    private fun observeQuery() {

        uiState.map { it.query }
            .debounce(500.milliseconds)
            .map { query -> query.trim() }
            .distinctUntilChanged()
            .flatMapLatest { query ->
                getFilteredQuotesUseCase(query)
            }
            .onEach { quotes ->
                updateQuotes(quotes)
            }.launchIn(viewModelScope)
    }

    private fun updateQuotes(quotes: List<Quote>) {
        _uiState.update { it.copy(quotes = quotes) }
    }

    fun onAction(action: QuoteListAction) {
        when (action) {
            is QuoteListAction.OnRandomQuote -> {
                // Handle random quote action
                onRandomQuote()
            }

            is QuoteListAction.OnQueryChange -> {
                // Handle query change action
                //queryFlow.value = action.query
                _uiState.update { it.copy(query = action.query) }
            }

            is QuoteListAction.OnToggleFavorite -> {
                // Handle favorite action
                onToggleFavorite(action.quote.id)
            }

            QuoteListAction.OnToggleSearchBar -> {
                _uiState.update { it.copy(showSearchBar = !it.showSearchBar) }
            }

            QuoteListAction.OnToggleFilterFavorites -> {
                _uiState.update { it.copy(showFilterFavorites = !it.showFilterFavorites) }
            }
            else -> {}
        }

    }



    private fun onRandomQuote() {
        viewModelScope.launch {
            val randomQuote = getRandomQuoteUseCase().first()
            notifyEvent(QuoteListEvent.OnNavigateToQuoteDetails(randomQuote))
        }
    }

    private fun onToggleFavorite(quoteId: Int) {
        viewModelScope.launch {
            toggleFavoriteUseCase(quoteId)
        }
    }

}