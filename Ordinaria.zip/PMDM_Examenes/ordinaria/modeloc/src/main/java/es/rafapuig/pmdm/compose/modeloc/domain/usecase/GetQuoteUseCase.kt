package es.rafapuig.pmdm.compose.modeloc.domain.usecase

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.domain.repository.QuoteRepository
import kotlinx.coroutines.flow.Flow

class GetQuoteUseCase(
    private val repository: QuoteRepository
) {
    operator fun invoke(quoteId: Int): Flow<Quote> {
        return repository.getQuoteById(quoteId)
    }
    //return QuoteManager.getQuoteById(quoteId)
}
