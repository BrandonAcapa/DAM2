package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.GetQuoteUseCase
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.ToggleFavoriteUseCase
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.SharingStarted.Companion.WhileSubscribed
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class QuoteDetailsViewModel(
    quoteId: Int,
    getQuoteUseCase: GetQuoteUseCase,
    private val toggleFavoriteUseCase: ToggleFavoriteUseCase
) : ViewModel() {

    /**
     * Get the quote with the given ID.
     */

    val quote = getQuoteUseCase(quoteId).stateIn(
        viewModelScope,
        started = WhileSubscribed(5000),
        initialValue = Quote()
    )

    /**
     * EL share necesita context mejor tengo que hacerlo con un event
     * y observarlo en un composable.
     */

    private val _eventChannel = Channel<QuoteDetailsEvent>()
    val events = _eventChannel.receiveAsFlow()

    private fun notifyEvent(event: QuoteDetailsEvent) {
        viewModelScope.launch {
            _eventChannel.send(event)
        }
    }

    /**
     * Handle quote details actions.
     */

    fun onAction(action: QuoteDetailsAction) {
        when (action) {
            is QuoteDetailsAction.OnFavoriteClick -> {
                // Handle favorite click
                onToggleFavorite(action.quote)
            }

            is QuoteDetailsAction.OnShareClick -> {
                // Handle share click
                onShare(action.quote)
            }
        }
    }

    private fun onShare(quote: Quote) {
        notifyEvent(QuoteDetailsEvent.OnShare(quote))
    }

    private fun onToggleFavorite(quote: Quote) {
        viewModelScope.launch {
            toggleFavoriteUseCase(quote.id)
        }
    }

}