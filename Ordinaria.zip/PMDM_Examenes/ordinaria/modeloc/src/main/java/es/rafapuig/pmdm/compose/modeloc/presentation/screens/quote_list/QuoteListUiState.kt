package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote

data class QuoteListUiState(
    val query: String = "",
    val quotes: List<Quote> = emptyList(),
    val showSearchBar: Boolean = false,
    val showFilterFavorites: Boolean = false,
)
