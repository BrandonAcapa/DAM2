package es.rafapuig.pmdm.compose.modeloc.domain.usecase

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.domain.repository.QuoteRepository
import kotlinx.coroutines.flow.Flow

class GetRandomQuoteUseCase(
    private val repository: QuoteRepository
) {
    operator fun invoke(): Flow<Quote> {
        return repository.getRandomQuote()
    }
}