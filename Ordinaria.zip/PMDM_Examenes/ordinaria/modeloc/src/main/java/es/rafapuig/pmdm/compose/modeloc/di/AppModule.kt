package es.rafapuig.pmdm.compose.modeloc.di

import es.rafapuig.pmdm.compose.modeloc.data.QuoteProvider
import es.rafapuig.pmdm.compose.modeloc.data.local.AppDatabase
import es.rafapuig.pmdm.compose.modeloc.data.local.QuoteDao
import es.rafapuig.pmdm.compose.modeloc.data.local.getInMemoryDatabase
import es.rafapuig.pmdm.compose.modeloc.data.local.toEntity
import es.rafapuig.pmdm.compose.modeloc.data.repository.QuoteRepositoryImpl
import es.rafapuig.pmdm.compose.modeloc.domain.repository.QuoteRepository
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.GetFilteredQuotesUseCase
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.GetQuoteUseCase
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.GetRandomQuoteUseCase
import es.rafapuig.pmdm.compose.modeloc.domain.usecase.ToggleFavoriteUseCase
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details.QuoteDetailsViewModel
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.QuoteListViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

val appModule = module {

    single {
        androidContext().getInMemoryDatabase().also { database ->
            CoroutineScope(Dispatchers.IO).launch {
                with(database.quoteDao()) {
                    if (getQuotesCount() == 0)
                        insertQuotes(QuoteProvider.programmingQuotes.map {
                            it.toEntity()
                        })
                }
            }
        }
    }

    single<QuoteDao> {
        get<AppDatabase>().quoteDao()
    }

    single<QuoteRepository> { QuoteRepositoryImpl(get()) }

    factory { GetRandomQuoteUseCase(get()) }
    factory { GetQuoteUseCase(get()) }
    factory { ToggleFavoriteUseCase(get()) }
    factory { GetFilteredQuotesUseCase(get()) }


    viewModel {
        QuoteListViewModel(
            getRandomQuoteUseCase = get(),
            toggleFavoriteUseCase = get(),
            getFilteredQuotesUseCase = get()
        )
    }

    viewModel { (quoteId: Int) ->
        QuoteDetailsViewModel(
            quoteId = quoteId,
            toggleFavoriteUseCase = get(),
            getQuoteUseCase = get()
        )
    }
}