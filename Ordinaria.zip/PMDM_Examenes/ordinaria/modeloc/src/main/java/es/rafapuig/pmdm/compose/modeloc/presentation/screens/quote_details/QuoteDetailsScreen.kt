package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details

import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import es.rafapuig.pmdm.compose.modeloc.data.QuoteProvider
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.navigation.LocalOnNavigationBack
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details.components.QuoteDetails
import es.rafapuig.pmdm.compose.modeloc.ui.components.TopAppBarWithBackNavigationButton
import es.rafapuig.pmdm.compose.modeloc.ui.theme.QuotesTheme

@Composable
fun QuoteDetailsScreen(
    quote: Quote?,
    onAction: (QuoteDetailsAction) -> Unit = {},
    onBack: () -> Unit = LocalOnNavigationBack.current
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBarWithBackNavigationButton(
                title = "Cita de ${quote?.author}",
                onBack = onBack
            )
        }
    ) { innerPadding ->
        val isLandscape =
            LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

        val modifier = if (isLandscape)
            Modifier.padding(innerPadding) else Modifier

        quote?.let { quote ->
            QuoteDetails(
                quote = quote,
                modifier = Modifier.padding(innerPadding),
                onFavoriteClick = { onAction(QuoteDetailsAction.OnFavoriteClick(quote)) },
                onShareClick = { onAction(QuoteDetailsAction.OnShareClick(quote)) }
            )
        } ?: run {
            ErrorScreen()
        }
    }
}

@Composable
fun ErrorScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "Error, no se ha encontrado la cita")
    }
}

@Preview(showSystemUi = true)
@Composable
fun QuoteDetailsScreenPreview() {
    QuotesTheme {
        QuoteDetailsScreen(
            QuoteProvider.getQuoteById(1) // null
        )
    }
}

