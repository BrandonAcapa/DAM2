package es.rafapuig.pmdm.compose.modeloc.domain.usecase

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.domain.repository.QuoteRepository
import kotlinx.coroutines.flow.Flow

class GetFilteredQuotesUseCase(
    private val quoteRepository: QuoteRepository
) {
    operator fun invoke(query: String): Flow<List<Quote>> {
        return quoteRepository.searchQuotes(query)
    }

}