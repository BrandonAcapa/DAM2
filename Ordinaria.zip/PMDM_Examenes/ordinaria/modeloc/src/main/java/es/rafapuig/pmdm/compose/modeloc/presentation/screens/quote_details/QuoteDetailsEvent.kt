package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote

sealed interface QuoteDetailsEvent {
    data class OnShare(val quote: Quote) : QuoteDetailsEvent
}