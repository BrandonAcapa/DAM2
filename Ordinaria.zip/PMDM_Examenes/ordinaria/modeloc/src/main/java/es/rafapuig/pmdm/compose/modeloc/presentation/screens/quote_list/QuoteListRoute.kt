package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list

import android.util.Log
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.rafapuig.pmdm.compose.modeloc.presentation.ObserveAsEvents
import org.koin.androidx.compose.koinViewModel

@Composable
fun QuoteListRoute(
    onNavigateToQuoteDetails: (Int) -> Unit = {},
    onNavigateToAbout: () -> Unit = {},
    viewModel: QuoteListViewModel = koinViewModel()
) {

    val uiState by viewModel.uiState
        .collectAsStateWithLifecycle()


    viewModel.events.ObserveAsEvents { event ->
        when (event) {

            is QuoteListEvent.OnNavigateToQuoteDetails -> {
                onNavigateToQuoteDetails(event.quote.id)
            }

        }
    }

    val onAction: (QuoteListAction) -> Unit = { action ->
        when (action) {

            is QuoteListAction.OnAbout -> {
                onNavigateToAbout()
            }

            is QuoteListAction.OnQuoteSelected -> {
                onNavigateToQuoteDetails(action.quote.id)
            }

            else -> {
                viewModel.onAction(action)
            }
        }
    }


    QuoteListScreen(
        uiState = uiState,
        onAction = onAction,
    )

}