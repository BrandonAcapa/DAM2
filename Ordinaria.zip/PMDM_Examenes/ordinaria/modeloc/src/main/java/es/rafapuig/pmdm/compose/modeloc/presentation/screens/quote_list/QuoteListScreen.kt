package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import androidx.compose.ui.unit.dp
import es.rafapuig.pmdm.compose.modeloc.data.QuoteProvider
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.components.AddQuoteDialog
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.components.QuoteListItem
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.components.QuotesTopAppBar
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.components.SearchBar
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.components.SwipeableQuoteListItem
import es.rafapuig.pmdm.compose.modeloc.ui.theme.QuotesTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuoteListScreen(
    uiState: QuoteListUiState = QuoteListUiState(),
    onAction: (QuoteListAction) -> Unit = {},
) {
    val scrollBehavior = TopAppBarDefaults
        .enterAlwaysScrollBehavior()


    Scaffold(
        modifier = Modifier
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            QuotesTopAppBar(
                scrollBehavior = scrollBehavior,
                onRandom = { onAction(QuoteListAction.OnRandomQuote) },
                onSearch = { onAction(QuoteListAction.OnToggleSearchBar) },
                toggleFavorite = uiState.showFilterFavorites,
                onFavorite = { onAction(QuoteListAction.OnToggleFilterFavorites) },
                onAbout = { onAction(QuoteListAction.OnAbout) }
            )
        }

    ) { innerPadding ->


        LazyColumn(
            //contentPadding = innerPadding,
            modifier = Modifier.padding(innerPadding)
        ) {
            if (uiState.showSearchBar) stickyHeader {
                SearchBar(
                    query = uiState.query,
                    onQueryChange = { newQuery ->
                        onAction(QuoteListAction.OnQueryChange(newQuery))
                    }
                )
            }

            items(uiState.quotes, key = { it.id }) { quote ->

                if (uiState.showFilterFavorites && !quote.isFavorite) return@items

                QuoteListItem(
                    quote = quote,
                    onQuoteClick = { quote ->
                        onAction(QuoteListAction.OnQuoteSelected(quote))
                    },
                    onFavoriteClick = { quote ->
                        onAction(QuoteListAction.OnToggleFavorite(quote))
                    },
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

    }
}


class QuoteListProvider : PreviewParameterProvider<List<Quote>> {
    override val values: Sequence<List<Quote>>
        get() = sequenceOf(QuoteProvider.programmingQuotes)
}


@Preview(showSystemUi = true)
@Composable
fun QuoteListScreenPreview(
    @PreviewParameter(QuoteListProvider::class)
    quotes: List<Quote>
) {
    QuotesTheme {
        QuoteListScreen(
            QuoteListUiState(quotes = quotes),
        )
    }
}