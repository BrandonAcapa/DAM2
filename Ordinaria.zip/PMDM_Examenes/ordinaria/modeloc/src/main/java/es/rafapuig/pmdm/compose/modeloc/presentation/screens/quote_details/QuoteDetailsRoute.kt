package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.rafapuig.pmdm.compose.modeloc.presentation.ObserveAsEvents
import es.rafapuig.pmdm.compose.modeloc.presentation.utils.share
import es.rafapuig.pmdm.compose.modeloc.navigation.LocalOnNavigationBack
import org.koin.androidx.compose.koinViewModel
import org.koin.core.parameter.parametersOf

@Composable
fun QuoteDetailsRoute(
    quoteId: Int,
    onBack: () -> Unit = LocalOnNavigationBack.current,
    viewModel: QuoteDetailsViewModel =
        koinViewModel { parametersOf(quoteId) }
) {

    val quote by viewModel.quote.collectAsStateWithLifecycle()

    /**
     * Observar los eventos de un solo uso
     */
    val context = LocalContext.current

    viewModel.events.ObserveAsEvents { event ->
        when (event) {
            is QuoteDetailsEvent.OnShare -> {
                event.quote.share(context)
            }
        }
    }

    QuoteDetailsScreen(
        quote = quote,
        onAction = viewModel::onAction,
        onBack = onBack
    )
}