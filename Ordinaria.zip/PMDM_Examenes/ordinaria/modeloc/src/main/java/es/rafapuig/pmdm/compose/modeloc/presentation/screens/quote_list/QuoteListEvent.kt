package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote

sealed interface QuoteListEvent {
    data class OnNavigateToQuoteDetails(val quote: Quote) : QuoteListEvent
}