package es.rafapuig.pmdm.compose.modeloc.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quotes")
data class QuoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "text") val text: String = "",
    @ColumnInfo(name = "author") val author: String = "",
    @ColumnInfo(name = "is_favorite") val isFavorite: Boolean = false
)
