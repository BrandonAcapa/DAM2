package es.rafapuig.pmdm.compose.modeloc.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.about.AboutScreen
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details.QuoteDetailsRoute
import es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list.QuoteListRoute
import kotlinx.serialization.Serializable


@Serializable
data object QuoteListScreenKey : NavKey

@Serializable
data class QuoteDetailsScreenKey(val quoteId: Int) : NavKey

@Serializable
data object AboutScreenKey : NavKey


val LocalOnNavigationBack = staticCompositionLocalOf<() -> Unit> { {} }


@Composable
fun NavigationRoot() {

    val backStack = rememberNavBackStack(QuoteListScreenKey)


    BackHandler(enabled = true) {
        if (backStack.size > 1) backStack.removeLastOrNull()
    }

    CompositionLocalProvider(LocalOnNavigationBack provides { backStack.removeLastOrNull() }) {

        NavDisplay(
            backStack = backStack,
            entryDecorators = listOf(
                rememberSaveableStateHolderNavEntryDecorator(), // Si no está crashea
                rememberViewModelStoreNavEntryDecorator() // Para limpiar el viewmodel de detalle
            ),

            //onBack = { if (backStack.size > 1) backStack.removeLastOrNull() },
            entryProvider = entryProvider {

                entry<QuoteListScreenKey> {
                    QuoteListRoute(
                        onNavigateToQuoteDetails = { quoteId ->
                            backStack.add(QuoteDetailsScreenKey(quoteId))
                        },
                        onNavigateToAbout = {
                            backStack.add(AboutScreenKey)
                        }
                    )
                }

                entry<QuoteDetailsScreenKey> { key ->
                    QuoteDetailsRoute(
                        quoteId = key.quoteId
                    )
                }

                entry<AboutScreenKey> {
                    AboutScreen(
                        //onBack = { backStack.removeLastOrNull() }
                    )
                }

            }
        )
    }

}


