package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote

sealed interface QuoteDetailsAction {
    data class OnFavoriteClick(val quote: Quote) : QuoteDetailsAction
    data class OnShareClick(val quote: Quote) : QuoteDetailsAction
}