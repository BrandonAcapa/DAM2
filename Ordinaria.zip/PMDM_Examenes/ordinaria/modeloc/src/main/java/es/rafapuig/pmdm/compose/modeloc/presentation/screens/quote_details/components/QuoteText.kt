package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_details.components

import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import es.rafapuig.pmdm.compose.modeloc.ui.theme.QuotesTheme

@Composable
fun QuoteText(
    quoteText :String,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    Text(
        modifier = modifier
            .verticalScroll(scrollState)
            .wrapContentHeight(align = Alignment.CenterVertically)
        ,
        text = "“$quoteText”",
        style = MaterialTheme.typography.headlineLarge,
        textAlign = TextAlign.Center,
        fontStyle = FontStyle.Italic
    )
}

@Preview(showBackground = true)
@Composable
fun QuoteTextPreview() {
    QuotesTheme {
        QuoteText(quoteText = "This is a sample quote text for preview.")
    }
}
