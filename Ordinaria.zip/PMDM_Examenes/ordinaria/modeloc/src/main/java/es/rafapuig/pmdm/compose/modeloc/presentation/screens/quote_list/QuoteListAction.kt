package es.rafapuig.pmdm.compose.modeloc.presentation.screens.quote_list

import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote

sealed interface QuoteListAction {
    object OnRandomQuote : QuoteListAction
    object OnAbout : QuoteListAction
    object OnToggleFilterFavorites : QuoteListAction
    object OnToggleSearchBar : QuoteListAction
    data class OnToggleFavorite(val quote: Quote) : QuoteListAction
    data class OnQueryChange(val query: String) : QuoteListAction
    data class OnQuoteSelected(val quote: Quote) : QuoteListAction
}