package es.rafapuig.pmdm.compose.modeloc.data.local

import es.rafapuig.pmdm.compose.modeloc.data.local.entity.QuoteEntity
import es.rafapuig.pmdm.compose.modeloc.domain.model.Quote

fun QuoteEntity.toDomain(): Quote {
    return Quote(
        id = id,
        text = text,
        author = author,
        isFavorite = isFavorite
    )
}

fun Quote.toEntity(): QuoteEntity {
    return QuoteEntity(
        id = id,
        text = text,
        author = author,
        isFavorite = isFavorite
    )
}