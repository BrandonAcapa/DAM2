package es.rafapuig.pmdm.compose.modeloc.domain.usecase

import es.rafapuig.pmdm.compose.modeloc.domain.repository.QuoteRepository
import kotlinx.coroutines.flow.first

class ToggleFavoriteUseCase(
    private val repository: QuoteRepository

) {
    suspend operator fun invoke(quoteId: Int) {
        /*val quote = repository.getQuoteById(quoteId).first()
        val updatedQuote = quote.copy(isFavorite = !quote.isFavorite)
        repository.updateQuote(updatedQuote)*/
        repository.toggleFavorite(quoteId)
    }
}