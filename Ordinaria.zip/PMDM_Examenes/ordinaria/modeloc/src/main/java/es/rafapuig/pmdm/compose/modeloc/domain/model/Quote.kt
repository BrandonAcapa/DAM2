package es.rafapuig.pmdm.compose.modeloc.domain.model

data class Quote(
    val id: Int = 0,
    val text: String = "",
    val author: String = "",
    val isFavorite: Boolean = false
)